# Interactive Painting Canvas

A Pen created on CodePen.

Original URL: [https://codepen.io/Hui-Shi-Ng/pen/ByoExaB](https://codepen.io/Hui-Shi-Ng/pen/ByoExaB).

