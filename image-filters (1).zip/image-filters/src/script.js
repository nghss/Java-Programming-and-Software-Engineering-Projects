var img = null;

function upload(){
  var input = document.getElementById("input");
  img = new SimpleImage(input);
  var canvas = document.getElementById("can");
  img.drawTo(canvas);
}

function grayscale(){
  var canvas = document.getElementById("can"); 
  for (var pixel of img.values()){
    var r = pixel.getRed(); 
    var g = pixel.getGreen();
    var b = pixel.getBlue();
    var avg = (r + g + b)/3;
    pixel.setRed(avg);
    pixel.setGreen(avg);
    pixel.setBlue(avg);
  }
  img.drawTo(canvas);
}

function red(){
  var canvas = document.getElementById("can"); 
  for (var pixel of img.values()){
    var avg = (pixel.getRed() + pixel.getGreen() + pixel.getBlue()) / 3; 
    if (avg < 128){
      pixel.setRed(avg * 2);
    }
    else{
      pixel.setRed(255);
      pixel.setGreen(2*avg - 255); 
      pixel.setBlue(2*avg-255);
    }
  }
  img.drawTo(canvas);
}

function rainbow(){
  var canvas = document.getElementById("can"); 
  var h = img.getHeight();
  if (img == null){
    alert("Image upload incomplete...")
  }
  for (var pixel of img.values()){
    var y = pixel.getY(); 
    var avg = (pixel.getRed() + pixel.getGreen() + pixel.getBlue())/3; 
    
    if (y < h/7){
      if (avg < 128){
        pixel.setRed(2*avg)
      }
      else{
      pixel.setRed(255); 
      }
    }
    else if (y > h/7 && y < (2*h/7)){
      if (avg < 128){
        pixel.setRed(2*avg);
        pixel.setGreen(0.8*avg);
      }
      else{
      pixel.setRed(255);
      pixel.setGreen(1.2*avg-51);
      pixel.setBlue(2*avg-255);
      }
    }
    else if (y > (2*h/7) && y < (3*h/7)){
      if(avg <128){
        pixel.setRed(2*avg);
        pixel.setGreen(2*avg);
      }
      else{
      pixel.setRed(255);
      pixel.setGreen(255); 
      pixel.setBlue(2*avg-255);
      }
    }
    else if (y > (3*h/7) && y < (4*h/7)){
      if (avg <128){
        pixel.setGreen(2*avg);
      }
      else{
      pixel.setRed(2*avg-255);
      pixel.setGreen(255);
      pixel.setBlue(2*avg-255);
      }
    }
    else if (y > (4*h/7) && y < (5*h/7)){
      if (avg<128){
        pixel.setBlue(2*avg);
      }
      else{
      pixel.setBlue(255);
        pixel.setRed(2*avg-255);
        pixel.setGreen(2*avg-255);
      }
    }
    else if (y > (5*h/7) && y < (6*h/7)){
      if (avg<128){
        pixel.setRed(1.6*avg);
        pixel.setBlue(1.6*avg);
      }
      else{
      pixel.setRed(0.4*avg + 153);
      pixel.setGreen(2*avg-255);
        pixel.setBlue(0.4*avg+153);
      }
    }
    else{
      pixel.setRed(255);
      pixel.setBlue(161);
    }
  }
  img.drawTo(canvas);
}

function blue(){
  var canvas = document.getElementById("can"); 
  for (var pixel of img.values()){
    var avg = (pixel.getRed() + pixel.getGreen() + pixel.getBlue()) / 3; 
    if (avg < 128){
      pixel.setBlue(avg * 2);
    }
    else{
      pixel.setBlue(255);
      pixel.setGreen(2*avg - 255); 
      pixel.setRed(2*avg-255);
    }
  }
  img.drawTo(canvas);
}

function sepia(){
  var canvas = document.getElementById("can");
  if (img != null){
    for (var pixel of img.values()){
      var r = pixel.getRed();
      var g = pixel.getGreen();
      var b = pixel.getBlue();
      pixel.setRed(0.393* r + 0.769*g + 0.189*b);
      pixel.setGreen(0.393* r + 0.769*g + 0.189*b);
      pixel.setBlue(0.393* r + 0.769*g + 0.189*b);
    }
    img.drawTo(canvas);
  }
}

function invert(){
  var canvas = document.getElementById("can");
  if (img != null){
    for (var pixel of img.values()){
      var r = pixel.getRed();
      var g = pixel.getGreen();
      var b = pixel.getBlue();
      pixel.setRed(255 - r);
      pixel.setGreen(255 - g);
      pixel.setBlue(255 - b);
    }
    img.drawTo(canvas);
  }
}


function clearcanvas(){
  var canvas = document.getElementById("can");
  var ctx = canvas.getContext("2d"); 
  ctx.clearRect(0,0,canvas.width, canvas.height);
}