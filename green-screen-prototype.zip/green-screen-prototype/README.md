# Green Screen Prototype

A Pen created on CodePen.

Original URL: [https://codepen.io/Hui-Shi-Ng/pen/MYadzjd](https://codepen.io/Hui-Shi-Ng/pen/MYadzjd).

