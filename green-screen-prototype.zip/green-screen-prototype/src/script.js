// global variables initialised 
// determines if image is loaded 
// when variable is used in multiple fns, then use global var

var fgImage = null;
var bgImage = null; 
var greenThreshold = 220;

function uploadfg(){
  var greenscreen = document.getElementById("greenscreen");
  fgImage = new SimpleImage(greenscreen);
  var canvas = document.getElementById("fgcan");
  fgImage.drawTo(canvas); 
}

function uploadbg(){
  var background = document.getElementById("background");
  bgImage = new SimpleImage(background);  // global
  var canvas = document.getElementById("bgcan");
  bgImage.drawTo(canvas);
}

function createcomp(){
  if (fgImage == null || !fgImage.complete()){ // determines if image is completely loaded
    alert("foreground not loaded");
    return;
  }
  if (bgImage == null || !bgImage.complete()){
    alert("background not loaded");
  }
  if (fgImage.getWidth() > bgImage.getWidth() || fgImage.getHeight > bgImage.getHeight()){
    alert("background image is too small");
    return;
  }
  clearcan();
  
  var output = new SimpleImage(fgImage.getWidth(), fgImage.getHeight());
  alert("Composite image loading...")
  for (var pixel of fgImage.values()){
    var x = pixel.getX(); 
    var y = pixel.getY(); 
    if (pixel.getGreen() > greenThreshold){
      var bgPixel = bgImage.getPixel(x,y);
      output.setPixel(x,y,bgPixel);
    }
    else{
      output.setPixel(x,y,pixel);
    }
  }
  var canvas = document.getElementById("fgcan");
  output.drawTo(canvas);
}

function clearcan(){
  var fgcan = document.getElementById("fgcan");
  var fgctx = fgcan.getContext("2d");
  fgctx.clearRect(0, 0, fgcan.width, fgcan.height);
  
  var bgcan = document.getElementById("bgcan");
  var bgctx = bgcan.getContext("2d");
  bgctx.clearRect(0, 0, bgcan.width, bgcan.height);
}

